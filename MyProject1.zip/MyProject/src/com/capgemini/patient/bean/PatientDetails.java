package com.capgemini.patient.bean;

import java.time.LocalDate;
import java.util.Date;

public class PatientDetails {
	private String patientName;
	private int patientAge;
	private int patientID;
	private String mobileNo;
	private String patientDesc;
	private LocalDate consultationDate;

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getPatientAge() {
		return patientAge;
	}

	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}

	public int getPatientID() {
		return patientID;
	}

	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPatientDesc() {
		return patientDesc;
	}

	public void setPatientDesc(String patientDesc) {
		this.patientDesc = patientDesc;
	}

	public LocalDate getConsultationDate() {
		return consultationDate;
	}

	public void setConsultationDate(LocalDate consultationDate) {
		this.consultationDate = consultationDate;
	}

}
