package com.capgemini.patient.ui;

import java.time.LocalDate;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.patient.bean.PatientDetails;
import com.capgemini.patient.service.PatientException;
import com.capgemini.patient.service.PatientHelper;
import com.capgemini.patient.service.PatientValidator;

public class PatientClient {

	public static void main(String[] args) throws PatientException {
		try
		{
		System.out.println("QualityCare Clinic software application.");
		int ch=-1;
		do {
			System.out.println("1.Add Patient Information\n2.Search Patient by Id\n3.Exit\n");
			Scanner scanner=new Scanner(System.in);
			ch=scanner.nextInt();
			PatientDetails details=new PatientDetails();
			PatientValidator validator=new PatientValidator();
			switch (ch) {
			case 1:
				Scanner scanner2=new Scanner(System.in);
				System.out.println("Enter the name of the Patient: ");
				String patientName=scanner2.nextLine();
				if(validator.validateName(patientName)) {
					details.setPatientName(patientName);
					System.out.println("Enter Patient Age: ");
					Scanner scanner3=new Scanner(System.in);
					String patientAge=scanner3.next();
					if(validator.validateAge(patientAge))
					{
						details.setPatientAge(Integer.parseInt(patientAge));
						System.out.println("Enter Patient phone number: ");
						String patientPhoneNumber=scanner3.next();
						if(validator.validateMobileNumber(patientPhoneNumber))
						{
							details.setMobileNo(patientPhoneNumber);
							System.out.println("Enter Description: ");
							String description=scanner3.next();
							if(validator.validateDesc(description))
							{
								details.setPatientDesc(description);
								Random ran=new Random();
								int patientsId=Math.abs(ran.nextInt());
								details.setPatientID(patientsId);
								
								details.setConsultationDate(LocalDate.now());
								PatientHelper helper=new PatientHelper();
								helper.addPatientDetails(details);
								
								
							}
							
						}
						
					}
				}
				break;
			case 2:
				PatientHelper helper=new PatientHelper();
				System.out.println("Enter patient Id");
				Scanner scanner3=new Scanner(System.in);
				int id=scanner3.nextInt();
				helper.searchPatient(id);
				break;
			case 3:
				System.exit(0);
			}
		}while(ch!=0);
	}
	catch(PatientException p)
		{
		System.err.println(p.getMessage());
		}
	}

}
