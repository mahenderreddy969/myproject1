package com.capgemini.patient.service;

public class PatientException extends Exception {

	public PatientException() {
		// TODO Auto-generated constructor stub
	}

	public PatientException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
