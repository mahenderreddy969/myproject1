package com.capgemini.patient.service;

import java.util.regex.Pattern;

public class PatientValidator {
	public static boolean validateName(String patientName) throws PatientException{
		String assetPattern="[A-Za-z ]{5,15}";
		boolean result=false;
		if(Pattern.matches(assetPattern, patientName))
		{
			result=true;
		}
		else
		{
			throw new PatientException("Patient name should be of minimum 5 characters and max of 15 characters only");
		}
		return result;
		
	}
	public boolean validateMobileNumber(String mobileNo) throws PatientException{
		String assetPattern="[7-9][0-9]{9}";
		boolean result=false;
		if(Pattern.matches(assetPattern,mobileNo))
		{
			result=true;
		}
		else
		{
			throw new PatientException("Patient mobile no should be of 10 digits only");
		}
		return result;
		
	}
	public boolean validateAge(String patientAge) throws PatientException{
		String assetPattern="[0-9]*";
		boolean result=false;
		if(Pattern.matches(assetPattern,patientAge))
		{
			if(Integer.parseInt(patientAge)>=1 && Integer.parseInt(patientAge)<=100)
			result=true;
			else
				throw new PatientException("Age should be between 1 and 100");
		}
		else
		{
			throw new PatientException("Age should be a number only");
		}
		return result;
		
	}
	public boolean validateDesc(String patientDesc) throws PatientException{
		String assetPattern="[A-Za-z ]{1,40}";
		boolean result=false;
		if(Pattern.matches(assetPattern,patientDesc))
		{
			result=true;
		}
		else
		{
			throw new PatientException("Description can be maximum of 40 characters only");
		}
		return result;
		
	}

}
