package com.capgemini.patient.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.patient.bean.PatientDetails;

public class PatientHelper {

	private  static ArrayList<PatientDetails> list=null;
	static
	{
	list=new ArrayList<PatientDetails>();
	
	}
	
	

	public void addPatientDetails(PatientDetails patientDetails){
		list.add(patientDetails);
		for(PatientDetails details:list)
			System.out.println(details.getPatientID());
	}

	public void searchPatient(int patientID) {
		System.out.println("--------------------------");
		for(PatientDetails details:list)
		{
			if(details.getPatientID()==patientID)
				System.out.println("Name of the Patient : "+details.getPatientName()+"\nAge : "+details.getPatientAge()+"\nPhone number: "+details.getMobileNo()+"\nDescription : "+details.getPatientDesc()+"\nConsultation Date : "+details.getConsultationDate());
		}
		
	}

}
